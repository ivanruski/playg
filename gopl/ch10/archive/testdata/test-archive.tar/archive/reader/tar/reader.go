package tar

import (
	"archive/tar"
	"fmt"
	"io"
	"os"
)

// ListContents returns a slice with the filenames included in the specified tar
func ListContents(tarName string) ([]string, error) {
	file, err := os.Open(tarName)
	if err != nil {
		return nil, err
	}

	result := []string{}
	tr := tar.NewReader(file)
	for {
		h, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, fmt.Errorf("advancing tar reader failed: %w", err)
		}

		result = append(result, h.Name)
	}

	return result, nil
}
